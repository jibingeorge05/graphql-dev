import React, { Component } from 'react';
import './App.css';
import ResponseView from './ResponseView/ResponseView';

async function loadingData() {
  //  const response =  await fetch('http://localhost:3000/', {
  //     method:'POST',
  //     headers:{'content-type':'application/json'},
  //     body:JSON.stringify({query: '{project(id: 2) {title,user_count}}'})
  //  })
   const response =  await fetch('http://localhost:5000/graphql', {
      method:'POST',
      headers:{'content-type':'application/json'},
      body:JSON.stringify({query: '{allProjects {edges {node {userCount, title}}}}'})
   })
   const responseBody =  await response.json();
   return responseBody.data.allProjects.edges;
}

class App extends Component {
   constructor(props) {
      super(props);
      this.state =  {projectDetails : ''}
      this.showData =  this.showData.bind(this);
   }
   
   showData() {

    loadingData().then(project => {
      console.log(JSON.stringify(project)); 

      const arrOfValues = [];
      project.map(proj => {
        const arrOfValue = [];
        arrOfValue.push(proj.node['title']);
        arrOfValue.push(parseInt(proj.node['userCount']));
        console.log(arrOfValue);
        arrOfValues.push(arrOfValue);
      });
      // console.log(arrOfValues);

      const dataset = {
        dimensions: ['name', 'score'],
        source: arrOfValues
      };

      // console.log(dataset);
      this.setState({projectDetails:dataset});
   });
   
   }

   render() {
      return (
         <div className = "App">
            <header>
               <h1 >GraphQL API Integration using PostGraphile</h1>
            </header>
            <br/><br/>
            <section>
               <button id = "btnGraph" onClick = {this.showData}>Generate Graph</button>
            </section>
            <br/><br/>
            {this.state.projectDetails !== '' && <ResponseView data={this.state.projectDetails}/>}
            <hr/>
         </div>
      );
   }
}

export default App;