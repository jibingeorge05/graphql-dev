// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';


// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import './index.css';
// import App from './App';
// import { ApolloClient } from 'apollo-boost';
// import gql from 'graphql-tag';
// import { Query } from 'react-apollo';

// const client = new ApolloClient({
//   uri: `http://localhost:3000/`
// })

// const GET_PRODUCTS = gql`
// query product($id: Int)
// {
//   product(id: $id){
//     name
//     category
//     rating
//   }
// }
// `

// class ProductList extends Component{
//   constructor(){
//     super()

//     this.state={
//       id:3
//     }
//   }
//   render(){
//     return(
//       <div>
//         <Query query={GET_PRODUCTS} client={client} variables={{id:this.state.id}}>
//           {({loading, error, data}) => {
//             if(loading) return <p>Loading...</p>
//             if(error) return <p>Error...</p>
//             return(
//               <div>
//                 <h3>{data.product.name}</h3>
//                 <h3>{data.product.category}</h3>
//               </div>
//             )
//           }}
//         </Query>
//       </div>
//     )
//   }
// }