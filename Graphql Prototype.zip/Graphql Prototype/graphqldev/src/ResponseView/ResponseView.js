import React, {useEffect, useState} from "react";
import ReactEcharts from "echarts-for-react";

export default function ResponseView(props) {

  const [dataset, setDataset] = useState('');
  const [pieOption, setPieOption] = useState('');

  useEffect(()=>{
    console.log(props);
    setDataset(props.data);
  }, [props.data]);

  useEffect(()=>{
    if(dataset !== ''){
       setPieOption({
        dataset: [dataset],
        series: [
          {
            type: 'pie',
            id: 'Score',
            radius: [0, '50%'],
            universalTransition: true,
            animationDurationUpdate: 1000
          }
        ]
      });
    }
  },[dataset])

  return (
    <>
    <div align="center">
      {pieOption !== '' ? <ReactEcharts option={pieOption} style={{ width: "600px", height: "400px" }} /> : null}
      </div>
    </>
  );
};