import "./ResponseView.css";
import React from "react";

function template() {
  return (
    <div className="response-view">
      <h1>ResponseView</h1>
    </div>
  );
};

export default template;
