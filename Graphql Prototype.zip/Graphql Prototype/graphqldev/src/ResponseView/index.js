import ResponseView from "./ResponseView";
export default ResponseView;
